#include <iostream>

using namespace std;

int main() {

	bool passed=true;

	if(passed) {
		cout << "You passed!" << endl;
	}

	return 0;
}