#include <iostream>

using namespace std;

int main() {

	bool passed=true;

	if(passed) {
		cout << "You passed!" << endl;
	} else {
		cout << "You failed!" << endl;
	}

	return 0;
}