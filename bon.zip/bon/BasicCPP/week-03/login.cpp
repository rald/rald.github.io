#include <iostream>

using namespace std;

int main() {

	const string USERNAME = "admin";
	const string PASSWORD = "1234";

	string username;
	string password;

	cout << "Username: ";
	getline(cin, username);

	cout << "Password: ";
	getline(cin, password);

	if(username!=USERNAME || password!=PASSWORD) {
		cout << "Access Denied" << endl;
	} else {
		cout << "Access Granted" << endl;
	}

	return 0;
}
