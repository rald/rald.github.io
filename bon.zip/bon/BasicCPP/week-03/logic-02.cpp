#include <iostream>

using namespace std;

int main() {

	int age;
	char vip;

	cout << "Age? ";
	cin >> age;

	cout << "VIP (y/n)? ";
	cin >> vip;

	if(age >= 18 || vip == 'y') {
		cout << "allowed to pass" << endl;
	} else {
		cout << "not allowed to pass" << endl;
	}

	return 0;
}
