#include <iostream>

using namespace std;

int main() {

	cout << endl;
	cout << "  []            " << endl;
	cout << " )  (    Relax  " << endl;
	cout << "(cola)          " << endl;
	cout << " )  (   Drink up" << endl;
	cout << "(____)          " << endl;
	cout << endl;

	return 0;
}
