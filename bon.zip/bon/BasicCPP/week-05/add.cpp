#include <iostream>

using namespace std;

double add(double a, double b) {
	return a + b;
}

int main() {

	cout << add(1, 2) << endl;

	return 0;
}
