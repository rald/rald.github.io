#include <iostream>
#include <random>

using namespace std;

int main() {

	int guess;
	int number;
	int tries=0;

	random_device rd;	// The spark: get a random seed from the hardware.
	mt19937 gen(rd());  // The engine: Random number generator (Mersenne Twister).
	uniform_int_distribution<> dist(1,100); // The filter: filters the output of gen from 1 to 100.

	number = dist(gen); // Gives you a random number from 1 to 100.

	cout << "Guess my number from 1 to 100." << endl;

	for(;;) {

		cout << "What is your guess? ";
		cin >> guess;

		if(guess<1 || guess>100) {
			cout << "Invalid input must be from 1 to 100." << endl;
		} else if(guess<number) {
			tries++;
			cout << "Higher!" << endl;
		} else if(guess>number) {
			tries++;
			cout << "Lower!" << endl;
		} else if(guess==number) {
			tries++;
			cout << "Correct! You've guessed my number in " << tries << " tries." << endl;
			break;
		}

	}

	cout << "Game Over." << endl;

	return 0;
}
