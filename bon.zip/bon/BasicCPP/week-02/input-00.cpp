#include <iostream>

using namespace std;

int main() {

	string name;
	int age;

	cout << "How old are you? ";
	cin >> age;

	cout << "What is your name? ";
	cin >> name;

	cout << "You are " << age << " years old." << endl;

	cout << "Your name is " << name << "." << endl;

	return 0;
}
