#include <iostream>

using namespace std;

int main() {

	string name = "Fria";
	int age = 26;
	char letterGrade = 'B';
	double grade = 85.75;
	bool passed = true;

	cout << name << endl;
	cout << age << endl;
	cout << letterGrade << endl;
	cout << grade << endl;
	cout << passed << endl;

	return 0;
}
