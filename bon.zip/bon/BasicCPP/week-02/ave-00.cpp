#include <iostream>

using namespace std;

int main() {

	double englishGrade = 78.25;
	double mathGrade    = 75.85;
	double scienceGrade = 79.75;
	double averageGrade = (englishGrade + mathGrade + scienceGrade) / 3;

	cout << "English: " << englishGrade << endl;
	cout << "Math:    " << mathGrade    << endl;
	cout << "Science: " << scienceGrade << endl;
	cout << "Average: " << averageGrade << endl;

	return 0;
}
