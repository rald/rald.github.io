#include <iostream>

using namespace std;

int main() {

	string name = "Fria";
	int age = 26;
	char letterGrade = 'B';
	double grade = 85.75;
	bool passed = true;

	cout << "Name: " << name << endl;
	cout << "Age: " << age << endl;
	cout << "Letter Grade: " << letterGrade << endl;
	cout << "Grade: " << grade << endl;
	cout << "Passed: " << passed << endl;

	return 0;
}
