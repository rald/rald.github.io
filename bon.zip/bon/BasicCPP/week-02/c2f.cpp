#include <iostream>
#include <iomanip>

using namespace std;

int main() {

	double centigrade;
	double fahrenheit;

	cout << "Centigrade? ";
	cin >> centigrade;

	fahrenheit = (centigrade * 9 / 5) + 32;

	cout << fixed << setprecision(2)
	     << centigrade << " Centigrade is "
	     << fahrenheit << " Fahrenheit." << endl;

	return 0;
}
