#include <iostream>

using namespace std;

int main() {

	string name;
	int age;
	char letterGrade;
	double grade;
	bool passed;

	name = "Fria";
	age = 26;
	letterGrade = 'B';
	grade = 85.75;
	passed = true;

	cout << name << endl;
	cout << age << endl;
	cout << letterGrade << endl;
	cout << grade << endl;
	cout << passed << endl;

	return 0;
}
