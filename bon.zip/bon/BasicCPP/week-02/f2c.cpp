#include <iostream>
#include <iomanip>

using namespace std;

int main() {

	double fahrenheit;
	double centigrade;

	cout << "Fahrenheit? ";
	cin >> fahrenheit;

	centigrade = (fahrenheit - 32) * 5 / 9;

	cout << fixed << setprecision(2)
         << fahrenheit << " Fahrenheit is "
         << centigrade << " Centigrade." << endl;

	return 0;
}
