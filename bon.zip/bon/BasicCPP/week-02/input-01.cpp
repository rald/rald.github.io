#include <iostream>

using namespace std;

int main() {

	int age;
	string fullName;

	cout << "How old are you? ";
	cin >> age;

	cin.ignore(); // clear all characters in buffer

	cout << "What is your full name? ";
	getline(cin, fullName); // read characters including spaces

	cout << "Your age is " << age << "." << endl;

	cout << "Your full name is " << fullName << "." << endl;

	return 0;
}
