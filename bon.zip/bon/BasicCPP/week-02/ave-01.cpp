#include <iostream>

using namespace std;

int main() {

	double englishGrade;
	double mathGrade;
	double scienceGrade;
	double averageGrade;

	cout << "Grade in English? "; cin >> englishGrade;
	cout << "Grade in Math?    "; cin >> mathGrade;
	cout << "Grade in Science? "; cin >> scienceGrade;

	averageGrade = (englishGrade + mathGrade + scienceGrade) / 3.0;

	cout << "Average Grade:    " << averageGrade << endl;

	return 0;
}
